using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.ProBuilder")]
[assembly: InternalsVisibleTo("Unity.ProBuilder.Editor")]
[assembly: InternalsVisibleTo("Unity.ProBuilder.Editor.Tests")]
