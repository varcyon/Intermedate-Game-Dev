﻿
public interface IRotate 
{
     void RotateThis();
}
