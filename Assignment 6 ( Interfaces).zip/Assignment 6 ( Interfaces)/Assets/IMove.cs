﻿

public interface IMove 
{
    void Move();

}
