﻿
public interface IChangeSize 
{
    void ChangeSize();
}
