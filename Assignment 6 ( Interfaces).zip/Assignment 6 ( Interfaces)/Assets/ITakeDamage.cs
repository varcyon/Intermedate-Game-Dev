﻿

public interface ITakeDamage
{
    void TakeDamage(int amount);
}
